<?php require_once('partials/header.inc');?>
<div class="container">
   Contact
</div>
<?php require_once('partials/footer.inc');?>