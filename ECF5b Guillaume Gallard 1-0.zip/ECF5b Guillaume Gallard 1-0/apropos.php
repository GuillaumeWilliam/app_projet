<?php require_once('partials/header.inc');?>
<div class="container">
   A propos
</div>
<?php require_once('partials/footer.inc');?>